# 🛠️ Cineflix Admin Panel — Standalone

## এটা কী?

Main user app থেকে Admin Panel সম্পূর্ণ আলাদা করা হয়েছে।  
এখন Admin Panel আলাদা Vercel project হিসেবে deploy হবে।

**সুবিধা:**
- Main app bundle ~40% ছোট → faster load
- Admin URL আলাদা → বেশি secure
- Admin panel আলাদা update করা যাবে

---

## 🔐 Login

Firebase Auth দিয়ে login — same email/password যা আগে ছিল।  
Admin এর URL শুধু তুমি জানবে, user জানবে না।

---

## 🚀 Vercel Deploy Steps

### ১. GitHub এ push করো
```bash
cd cineflix-admin
git init
git add .
git commit -m "cineflix admin panel"
git remote add origin https://github.com/তোমার-username/cineflix-admin.git
git push -u origin main
```

### ২. Vercel এ deploy
1. [vercel.com](https://vercel.com) → "New Project"
2. GitHub repo select করো (cineflix-admin)
3. **Framework:** Vite
4. **Build Command:** `npm run build`
5. **Output Directory:** `dist`
6. Deploy করো ✅

### ৩. Custom domain (optional)
Vercel free plan এ `cineflix-admin.vercel.app` এর মতো URL পাবে।  
চাইলে custom domain যোগ করতে পারো।

---

## ⚠️ Important

Main app (`cineflix-main`) এ AdminPanel **এখনও আছে** lazy loaded হিসেবে।  
5-tap secret access কাজ করবে।

কিন্তু তুমি চাইলে main app থেকে AdminPanel সম্পূর্ণ সরিয়ে দিতে পারো।  
তাহলে শুধু এই admin URL দিয়েই access হবে।

---

## 📁 Structure
```
cineflix-admin/
├── src/
│   ├── AdminApp.tsx        ← Standalone wrapper
│   ├── main.tsx
│   ├── firebase.ts
│   ├── types.ts
│   └── components/
│       └── AdminPanel.tsx  ← Full admin panel
├── index.html
├── vite.config.ts
├── vercel.json
└── package.json
```
