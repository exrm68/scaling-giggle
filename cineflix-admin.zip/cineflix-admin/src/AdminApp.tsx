import React from 'react';
import AdminPanel from './components/AdminPanel';

// ✅ Standalone Admin App
// এটা আলাদা Vercel project হিসেবে deploy হবে
// URL: cineflix-admin.vercel.app (বা যেকোনো নাম)
// Main user app এ AdminPanel আর থাকবে না

const AdminApp: React.FC = () => {
  return (
    <div style={{ background: '#0d0d10', minHeight: '100vh' }}>
      {/* AdminPanel সরাসরি render — onClose just reloads */}
      <AdminPanel onClose={() => window.location.reload()} />
    </div>
  );
};

export default AdminApp;
